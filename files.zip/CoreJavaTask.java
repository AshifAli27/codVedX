import java.util.Scanner;

/**
 * TASK 1: Core Java Problem Solving
 * -----------------------------------
 * This program demonstrates:
 * 1. Checking whether a number is an Armstrong Number
 * 2. Generating a Fibonacci Series using a method
 *
 * Skills used: loops, conditionals, methods, input validation
 */
public class CoreJavaTask {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // ---------- Part 1: Armstrong Number ----------
        System.out.print("Enter a number to check if it's an Armstrong number: ");

        // Input validation: make sure the user actually typed an integer
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input! Please enter a valid integer.");
            scanner.next(); // discard the bad input
            System.out.print("Enter a number to check if it's an Armstrong number: ");
        }
        int number = scanner.nextInt();

        if (isArmstrong(number)) {
            System.out.println(number + " is an Armstrong number.");
        } else {
            System.out.println(number + " is NOT an Armstrong number.");
        }

        // ---------- Part 2: Fibonacci Series ----------
        System.out.print("\nEnter how many Fibonacci terms you want to generate: ");

        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input! Please enter a valid positive integer.");
            scanner.next();
            System.out.print("Enter how many Fibonacci terms you want to generate: ");
        }
        int terms = scanner.nextInt();

        if (terms <= 0) {
            System.out.println("Please enter a number greater than 0.");
        } else {
            System.out.println("Fibonacci Series with " + terms + " terms:");
            generateFibonacci(terms);
        }

        scanner.close();
    }

    /**
     * Checks whether a given number is an Armstrong number.
     * An Armstrong number equals the sum of its own digits,
     * each raised to the power of the number of digits.
     * Example: 153 = 1^3 + 5^3 + 3^3
     */
    public static boolean isArmstrong(int number) {
        int originalNumber = number;
        int numberOfDigits = String.valueOf(Math.abs(number)).length();
        int sum = 0;

        int temp = Math.abs(number);
        while (temp > 0) {
            int digit = temp % 10;
            sum += Math.pow(digit, numberOfDigits);
            temp /= 10;
        }

        return sum == originalNumber;
    }

    /**
     * Generates and prints the first `terms` numbers
     * of the Fibonacci series using a loop (no recursion,
     * so it stays efficient even for larger inputs).
     */
    public static void generateFibonacci(int terms) {
        long first = 0, second = 1;

        for (int i = 1; i <= terms; i++) {
            System.out.print(first + " ");
            long next = first + second;
            first = second;
            second = next;
        }
        System.out.println(); // move to a new line after printing
    }
}
