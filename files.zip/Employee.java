/**
 * TASK 2: Object-Oriented Programming Design
 * -------------------------------------------
 * Demonstrates:
 * - Encapsulation (private fields + public getters/setters)
 * - Method overloading (two versions of calculateAnnualSalary)
 * - toString() override
 */
public class Employee {

    // Encapsulation: fields are private, accessed only through methods
    private int id;
    private String name;
    private String department;
    private double salary; // monthly salary

    // Constructor
    public Employee(int id, String name, String department, double salary) {
        this.id = id;
        this.name = name;
        this.department = department;
        this.salary = salary;
    }

    // ---------- Getters and Setters (Encapsulation) ----------
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDepartment() {
        return department;
    }

    public void setDepartment(String department) {
        this.department = department;
    }

    public double getSalary() {
        return salary;
    }

    public void setSalary(double salary) {
        if (salary < 0) {
            System.out.println("Salary cannot be negative. Keeping previous value.");
            return;
        }
        this.salary = salary;
    }

    // ---------- Method Overloading ----------
    // Version 1: simple annual salary (monthly * 12)
    public double calculateAnnualSalary() {
        return salary * 12;
    }

    // Version 2: annual salary including a bonus percentage
    public double calculateAnnualSalary(double bonusPercentage) {
        double annual = salary * 12;
        double bonus = annual * (bonusPercentage / 100);
        return annual + bonus;
    }

    // ---------- Display method ----------
    public void displayDetails() {
        System.out.println(toString());
    }

    // ---------- toString() override ----------
    @Override
    public String toString() {
        return "Employee Details:\n" +
                "  ID          : " + id + "\n" +
                "  Name        : " + name + "\n" +
                "  Department  : " + department + "\n" +
                "  Monthly Pay : " + salary + "\n" +
                "  Annual Pay  : " + calculateAnnualSalary();
    }

    // ---------- Main method to test the class ----------
    public static void main(String[] args) {
        Employee emp1 = new Employee(101, "Aditi Sharma", "Engineering", 55000.0);

        emp1.displayDetails();

        System.out.println("\nAnnual salary without bonus: " + emp1.calculateAnnualSalary());
        System.out.println("Annual salary with 10% bonus: " + emp1.calculateAnnualSalary(10));

        // Demonstrate encapsulation: updating salary through setter
        emp1.setSalary(60000);
        System.out.println("\nAfter salary update:");
        emp1.displayDetails();
    }
}
